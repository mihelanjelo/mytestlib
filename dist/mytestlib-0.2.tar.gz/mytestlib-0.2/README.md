It's my testing library
python -m unittest mytestlib.tests